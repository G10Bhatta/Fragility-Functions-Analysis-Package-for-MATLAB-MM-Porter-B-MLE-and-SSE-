%% Introduction  - Main File 

%This code develops experimental or empirical fragility functions for 
%a systems based on damage observations and corresponding intensity measures 
%obtained from either experiments or field-surveys, respectively. 

% Required information:
% 1.  Damage state titles (currently, has max limit of 3 damage states, can
% be extended if required. 
% 2.  Intensity Measures (IMs) for the observed damage
% 3.  Maximum IMs the specimens withstood without reaching the damage state
% 4.  Figure plot characteristics
% 5.  Damage state colors for figures
% 6. Additional paramaters such as:
%   a. Checking only lognormal CDF, 
%   b. Contraining ispersion with a range or to a value, 
%   c. Whether only unique IMs are to be used for analysis
%   d. Pierce's criteria to eliminate outliers (Ross 2003)

% Output:
% 1. Gives CDF function parameters in the command window
% 2. Plots the CDF functions

% ------------------------------------------------------------------ %

%Fragility functions (or curves) are used to visually represent the 
%probability of failure or damage to a structure (or system) in relation 
% to different levels of seismic intensity or loading. 
% The fragility functions can be modelled using cumulative distribution 
% functions (CDFs) defined by a set of parameters 
% (also known as parametric fragility functions). 
% These parameters can be estimated using Method-of-Moments (MM) or Method A 
% (Porter, K. et al., 2006; Porter, Keith et al., 2007), 
% Maximum Likelihood Estimation (MLE) (Cremen and Baker, 2019; Rota et al., 
% 2008; Shinozuka et al., 2000), Sum of Squared Errors (SSE) 
% (Baker, J. W., 2015; Porter, K. et al., 2006; Porter, Keith et al., 2010) 
% or Porter Method B (PB) (Porter, K. et al., 2006; Porter, Keith et al., 2007). 
% MLE is generally preferred over the MM and SSE (Cremen and Baker, 2019; 
% Lallemant et al., 2015). 
%-------------------------------------------------------------------------
% Date 09/17/2024
% Developed by Jitendra Bhatta. Postdoctoral Scholar, Department of Civil & 
% Systems Engineering, Johns Hopkins University, Baltimore, Maryland, US 
% and Guest researcher at National Institute of Science and Technology (NIST), 
% Gaithersburg, Maryland, US, ORCID number: 0000-0002-7188-8292
% email: jitendra.bhatta@canterbury.ac.nz
%-------------------------------------------------------------------------
clc; clear all;
%% --------------------- [SYSTEM/COMPONENT NAME] --------------

% Specify Damage state titles
system_name="LTF plasterboard Sheathed Walls";
DS_title1="D1Minor";        %DS1
DS_title2="D2Major";        %DS2
DS_title3="D3Replace";      %DS3

% Intensity Measure (IM)/Engineering Demand Parameter (EDP) unit
IM_unit="ISD (%)";


% Damage data for the system system
% IMs when the damage states were observed
% Example
DS_intensity1=[0.63 0.63 0.63 0.63 0.63 0.63 0.48 0.48 0.5 0.5 0.5 0.5];                 %DS1
DS_intensity2=[0.92 0.92 0.92 0.92 0.92 0.92 0.72 0.7 0.69 0.96 0.69 0.69];                  %DS2
DS_intensity3=[1.45 1.5 1.34 1.88 1.34 1.34];                                                       %DS3 


% No damage data: data where damage state was not observed i.e. Max IMs of
% tested specimens where damage state was not observed)
%Example:

Max_EDP_no_damage1=[];       %DS1
Max_EDP_no_damage2=[];       %DS2
Max_EDP_no_damage3=[1.79 1.79 1.79 1.79 1.79 1.79];   %DS3

% 0.38 0.38 0.38 0.38 0.38 0.38 0.36 0.17 0.31 0.17 0.31 0.17 0.31 0.17 0.31 0.63 0.63 0.63 0.63 0.63 0.63 0.92 0.6 0.6 0.5 0.5 0.5 0.5 0.69 0.92 0.92 0.92 1.21 0.92 0.92 0.72 0.7 0.69 0.96 0.69 0.690.38 0.38 0.38 0.38 0.38 0.38 0.36 0.17 0.31 0.17 0.31 0.17 0.31 0.17 0.31 0.63 0.63 0.63 0.63 0.63 0.63 0.92 0.6 0.6 0.5 0.5 0.5 0.5 0.69 0.92 0.92 0.92 1.21 0.92 0.92 0.72 0.7 0.69 0.96 0.69 0.69

% Figure plot characteristics
x_axis_name= IM_unit;
xmin=0;                                         % specify minumum IM for plot
xmax=3;                                         % specify maximum IM for plot
x=linspace(xmin,xmax);
% Specify Damage state colors for plotting
green=[0.4660 0.6740 0.1880];                   % DS1
orange=[0.9290 0.6940 0.1250];                  % DS2
dark_orange=[0.8500 0.3250 0.0980];             % DS3

color=[green;orange;dark_orange];               % Change this accordingly4

% Define contraints or what is needed to be plotted
only_normal=1;          % only fits and plots log-normal CDF, if = 1. 
                        % if =0, then checks all the CDFs in the MATLAB and
                        % provides best fits based on least AIC or SSE
                        % measures

std_constrain=1;        % If std_constrain=1, constrains standard deviation and dispersion between 0.2 and 0.6 for SSE and MLE for Normal and Log-normal distribution, respectively.   
                        % The lower bound (LB) and upper bound (UB) can
                        % values can be changed in jb_fit_mle.m and
                        % jb_fit_sse.m files. 
num_bestfits=5;         % If only_normal=0, Specify the number of best fit CDFs to be plotted.

if only_normal==1  
    num_bestfits=1;     % if only normal=1, then checks only lognormal. so only 1 CDF to plot. 
end

uniQ=0;                 % uniQ=1, if only unique values of intensities measures from data are to be sent for analysis. By default uniQ=0.

pierce=0;               % specify if Pierce criteria (Ross 2003) is to be run to eliminate outliers from IMs for MLE and SSE methods.MM method runs Pierce criteria.

assumed_dispersion =0.4; % this assumes all the functions to have dispersion as given for plotting - provides additional figure;

option =2;               % Specify which method to implement in Porter Method B. %default option =2 (solves in approx log-norm space).
% Option 1:
% The prescribed formula to obtain norm inverse of collapse fraction by porter is :
%               yj=norminv((mj+1)./(Mj+1))
% It doesn't give values for norminv(0) and norminv(1). Hence, non-convergent for binary data (0,1). 
% Option 2:
% The collapse fractions are calculated as below, where, approximate collapse 
% fractions are usef for fractions equal to 0 and 1.
%{
fr=mj./Mj;                              
fr(N)=mj(N)./Nj;
fr(fr==1)=0.999;               %Approximation to 1
fr(fr==0)=0.001;               %Approximation to 0
yj=norminv(fr);
%}

%Option 3: involves fitting linear curve to mj./Mj vs. average demand in
%real space. Therefore, doesn't have issue of binary data. 
%% Method of Moments or Porter A method
% Steps
% 1. Peirce's criterion (Ross 2003) to eliminate doubtful observations.
% outliers  FEMA P-58 Annex H (2012)
% 2. Calculation of Median and Disperion and plotting
% 3. Lilliefors Goodness of fit testing (Lilliefors 1967) and other normality test
plot_title=append(system_name," (MM)");
figure
try
[ThetaA1,BetaA1, Lilie_testA1, NA1]=Fragility_FDC_A(DS_intensity1,std_constrain,xmin, xmax, plot_title, x_axis_name, DS_title1,color(1,:));
catch
  ThetaA1=NaN; BetaA1=NaN; Lilie_testA1=NaN;
end
try
[ThetaA2,BetaA2, Lilie_testA2, NA2]=Fragility_FDC_A(DS_intensity2,std_constrain,xmin, xmax, plot_title, x_axis_name, DS_title2,color(2,:));
catch
  ThetaA2=NaN; BetaA2=NaN; Lilie_testA2=NaN;
end
try
[ThetaA3,BetaA3, Lilie_testA3, NA3]=Fragility_FDC_A(DS_intensity3,std_constrain, xmin, xmax, plot_title, x_axis_name, DS_title3,color(3,:));
catch
  ThetaA3=NaN; BetaA3=NaN; Lilie_testA3=NaN;
end
grid on
hold off
saveas(gca,[pwd '/Fragility Analysis Result Figures/Output Folder/MM_beta_data.jpg']); % specify directory and figure name to save this plot
Theta_MM=[ThetaA1, ThetaA2, ThetaA3]';
Beta_MM=[BetaA1, BetaA2, BetaA3]';
Lilie_test_MM=[Lilie_testA1, Lilie_testA2, Lilie_testA3]';
FS_MM=table(Theta_MM,Beta_MM,Lilie_test_MM)
%% Fitting collapse fractions by MLE, SSE and Porter B


% DS1
fi_no_damage1=0*ones(1, length(Max_EDP_no_damage1));
Max_EDP_damage1=DS_intensity1;
fi_damage1=1*ones(1, length(Max_EDP_damage1));
Max_EDP1=[Max_EDP_damage1 Max_EDP_no_damage1];
fi1=[fi_damage1  fi_no_damage1];
IM1=Max_EDP1;
num_gms1=ones(1,length(IM1));
num_collapse1=fi1;

% DS2
Max_EDP_no_damage2_r=sort(Max_EDP_no_damage2);
fi_no_damage2=0*ones(1, length(Max_EDP_no_damage2));
Max_EDP_damage2=DS_intensity2;
fi_damage2=1*ones(1, length(Max_EDP_damage2));
Max_EDP2=[Max_EDP_damage2 Max_EDP_no_damage2];
fi2=[fi_damage2 fi_no_damage2];
IM2=Max_EDP2;
num_gms2=ones(1,length(IM2));
num_collapse2=fi2;

% DS3
fi_no_damage3=0*ones(1, length(Max_EDP_no_damage3));
Max_EDP_damage3=DS_intensity3;
fi_damage3=1*ones(1, length(Max_EDP_damage3));
Max_EDP3=[Max_EDP_damage3 Max_EDP_no_damage3];
fi3=[fi_damage3 fi_no_damage3];
IM3=Max_EDP3;
num_gms3=ones(1,length(IM3));
num_collapse3=fi3;

% MLE
figure
plot_title=append(system_name," (MLE)");
RMLE1=fittoecdfmle(Max_EDP_damage1,IM1, num_gms1,num_collapse1,only_normal, std_constrain,x_axis_name,xmin,xmax,plot_title,DS_title1,color(1,:),num_bestfits,uniQ,pierce);
hold on
RMLE2=fittoecdfmle(Max_EDP_damage2,IM2, num_gms2,num_collapse2,only_normal, std_constrain,x_axis_name,xmin,xmax,plot_title,DS_title2,color(2,:),num_bestfits,uniQ,pierce);
hold on
RMLE3=fittoecdfmle(Max_EDP_damage3,IM3, num_gms3,num_collapse3,only_normal, std_constrain,x_axis_name,xmin,xmax,plot_title,DS_title3,color(3,:),num_bestfits,uniQ,pierce);
hold off
saveas(gca,[pwd '/Fragility Analysis Result Figures/Output Folder/MLE_beta_data.jpg']);
if only_normal==1
    Theta_MLE=[exp(RMLE1.parameters_sort(1)), exp(RMLE2.parameters_sort(1)), exp(RMLE3.parameters_sort(1))]';
    Beta_MLE=[RMLE1.parameters_sort(2), RMLE2.parameters_sort(2), RMLE3.parameters_sort(2)]';
    FS_MLE=table(Theta_MLE,Beta_MLE)
end

% SSE
figure
plot_title=append(system_name," (SSE)");
RSSE1=fittoecdfsse(Max_EDP_damage1,IM1, num_gms1,num_collapse1,only_normal, std_constrain,x_axis_name,xmin,xmax,plot_title,DS_title1,color(1,:),num_bestfits,uniQ,pierce);
hold on
RSSE2=fittoecdfsse(Max_EDP_damage2,IM2, num_gms2,num_collapse2,only_normal, std_constrain,x_axis_name,xmin,xmax,plot_title,DS_title2,color(2,:),num_bestfits,uniQ,pierce);
hold on
RSSE3=fittoecdfsse(Max_EDP_damage3,IM3, num_gms3,num_collapse3,only_normal, std_constrain,x_axis_name,xmin,xmax,plot_title,DS_title3,color(3,:),num_bestfits,uniQ,pierce);
hold off
saveas(gca,[pwd '/Fragility Analysis Result Figures/Output Folder/SSE_beta_data.jpg']);
if only_normal==1
    Theta_SSE=[exp(RSSE1.parameters_sort(1)), exp(RSSE2.parameters_sort(1)), exp(RSSE3.parameters_sort(1))]';
    Beta_SSE=[RSSE1.parameters_sort(2), RSSE2.parameters_sort(2), RSSE3.parameters_sort(2)]';
    FS_SSE=table(Theta_SSE,Beta_SSE)
end

% Porter B
plot_title=append(system_name," (Porter Method B (PB))");
figure
[ThetaB1,BetaB1,Lilie_testB1,IMPB1, num_gmsPB1, num_collapsePB1]=Fragility_FDC_B(Max_EDP1,fi1,std_constrain,option, xmin, xmax, plot_title, x_axis_name, DS_title1,color(1,:));
hold on
[ThetaB2,BetaB2,Lilie_testB2,IMPB2, num_gmsPB2, num_collapsePB2]=Fragility_FDC_B(Max_EDP2,fi2,std_constrain,option, xmin, xmax, plot_title, x_axis_name, DS_title2,color(2,:));
hold on
[ThetaB3,BetaB3,Lilie_testB3,IMPB3, num_gmsPB3, num_collapsePB3]=Fragility_FDC_B(Max_EDP3,fi3,std_constrain,option, xmin, xmax, plot_title, x_axis_name, DS_title3,color(3,:));
hold off
saveas(gca,[pwd '/Fragility Analysis Result Figures/Output Folder/PB_beta_data.jpg']);

if only_normal==1
    Theta_PB=[ThetaB1, ThetaB2, ThetaB3]';
    Beta_PB=[BetaB1, BetaB2, BetaB3]';
    Lilie_test_PB=[Lilie_testB1, Lilie_testB2, Lilie_testB3]';
    try
    Average_demand_PB=[IMPB1; IMPB2; IMPB3];
    N_PB=[num_gmsPB1;num_gmsPB2;num_gmsPB3];
    M_PB=[num_collapsePB1; num_collapsePB2;num_collapsePB3];
    FS_PB=table(Theta_PB,Beta_PB,Lilie_test_PB,Average_demand_PB, N_PB,M_PB)
    catch
    FS_PB=table(Theta_PB,Beta_PB,Lilie_test_PB)
    end
end

%% plotting the results in comaparable graphs for lognormal only (norm_only ==1)
% Fragility system  with disperson given by data
if only_normal==1
figure;
%MM
yDS1_MM = cdf('Normal',log(x),log(FS_MM.Theta_MM(1)),FS_MM.Beta_MM(1));
plot(x,yDS1_MM,'LineWidth',2,'DisplayName',"Superficial(MM)",'Color',color(1,:));
hold on
yDS2_MM = cdf('Normal',log(x),log(FS_MM.Theta_MM(2)),FS_MM.Beta_MM(2));
plot(x,yDS2_MM,'LineWidth',2,'DisplayName',"Compromised(MM)",'Color',color(2,:));
hold on
yDS3_MM = cdf('Normal',log(x),log(FS_MM.Theta_MM(3)),FS_MM.Beta_MM(3));
plot(x,yDS3_MM,'LineWidth',2,'DisplayName',"Critical(MM)",'Color',color(3,:));
hold on
%MLE
yDS1_MLE = cdf('Normal',log(x),log(FS_MLE.Theta_MLE(1)),FS_MLE.Beta_MLE(1));
plot(x,yDS1_MLE,'LineWidth',2,'DisplayName',"Superficial(MLE)",'Color',color(1,:),'LineStyle','--');
hold on
yDS2_MLE = cdf('Normal',log(x),log(FS_MLE.Theta_MLE(2)),FS_MLE.Beta_MLE(2));
plot(x,yDS2_MLE,'LineWidth',2,'DisplayName',"Compromised(MLE)",'Color',color(2,:),'LineStyle','--');
hold on
yDS3_MLE = cdf('Normal',log(x),log(FS_MLE.Theta_MLE(3)),FS_MLE.Beta_MLE(3));
plot(x,yDS3_MLE,'LineWidth',2,'DisplayName',"Critical(MLE)",'Color',color(3,:),'LineStyle','--');
hold on
%SSE
yDS1_SSE = cdf('Normal',log(x),log(FS_SSE.Theta_SSE(1)),FS_SSE.Beta_SSE(1));
plot(x,yDS1_SSE,'LineWidth',2,'DisplayName',"Superficial(SSE)",'Color',color(1,:),'LineStyle',':',"Marker",'+');
hold on
yDS2_SSE = cdf('Normal',log(x),log(FS_SSE.Theta_SSE(2)),FS_SSE.Beta_SSE(2));
plot(x,yDS2_SSE,'LineWidth',2,'DisplayName',"Compromised(SSE)",'Color',color(2,:),'LineStyle',':',"Marker",'+');
hold on
yDS3_SSE = cdf('Normal',log(x),log(FS_SSE.Theta_SSE(3)),FS_SSE.Beta_SSE(3));
plot(x,yDS3_SSE,'LineWidth',2,'DisplayName',"Critical(SSE)",'Color',color(3,:),'LineStyle',':',"Marker",'+');
hold on
%PB
yDS1_PB = cdf('Normal',log(x),log(FS_PB.Theta_PB(1)),FS_PB.Beta_PB(1));
plot(x,yDS1_PB,'LineWidth',2,'DisplayName',"Superficial(PB)",'Color',color(1,:),'LineStyle','-.',"Marker",'o');
hold on
yDS2_PB = cdf('Normal',log(x),log(FS_PB.Theta_PB(2)),FS_PB.Beta_PB(2));
plot(x,yDS2_PB,'LineWidth',2,'DisplayName',"Compromised(PB)",'Color',color(2,:),'LineStyle','-.',"Marker",'o');
hold on
yDS3_PB = cdf('Normal',log(x),log(FS_PB.Theta_PB(3)),FS_PB.Beta_PB(3));
plot(x,yDS3_PB,'LineWidth',2,'DisplayName',"Critical(PB)",'Color',color(3,:),'LineStyle','-.',"Marker",'o');
hold on
title(append(system_name));
ax=gca;
ax.FontSize=18;
xlabel(x_axis_name)
ylabel("Probability of exceedence");
hold on
legend('Location',"southeast")
legend show
ax.XTick=xmin:0.5:xmax;
x0=10;
y0=30;
wdt=1000;
hgt=600;
grid on
set(gcf,'position',[x0,y0,wdt,hgt]);
saveas(gca,[pwd '/Fragility Analysis Result Figures/Output Folder/ALL_sys_beta_data.jpg']);
end
%% plotting the results in comaparable graphs  for lognormal only (norm_only ==1) 
% Fragility system  with disperson = assumed_beta;
if only_normal==1
x=linspace(xmin,xmax);
figure;
title_plot=append(system_name," with assumed disperson of ",string(assumed_dispersion));
%MM
yDS1_MM = cdf('Normal',log(x),log(FS_MM.Theta_MM(1)),assumed_dispersion);
plot(x,yDS1_MM,'LineWidth',2,'DisplayName',"Superficial(MM)",'Color',color(1,:));
hold on
yDS2_MM = cdf('Normal',log(x),log(FS_MM.Theta_MM(2)),assumed_dispersion);
plot(x,yDS2_MM,'LineWidth',2,'DisplayName',"Compromised(MM)",'Color',color(2,:));
hold on
yDS3_MM = cdf('Normal',log(x),log(FS_MM.Theta_MM(3)),assumed_dispersion);
plot(x,yDS3_MM,'LineWidth',2,'DisplayName',"Critical(MM)",'Color',color(3,:));
hold on
%MLE
yDS1_MLE = cdf('Normal',log(x),log(FS_MLE.Theta_MLE(1)),assumed_dispersion);
plot(x,yDS1_MLE,'LineWidth',2,'DisplayName',"Superficial(MLE)",'Color',color(1,:),'LineStyle','--');
hold on
yDS2_MLE = cdf('Normal',log(x),log(FS_MLE.Theta_MLE(2)),assumed_dispersion);
plot(x,yDS2_MLE,'LineWidth',2,'DisplayName',"Compromised(MLE)",'Color',color(2,:),'LineStyle','--');
hold on
yDS3_MLE = cdf('Normal',log(x),log(FS_MLE.Theta_MLE(3)),assumed_dispersion);
plot(x,yDS3_MLE,'LineWidth',2,'DisplayName',"Critical(MLE)",'Color',color(3,:),'LineStyle','--');
hold on
%SSE
yDS1_SSE = cdf('Normal',log(x),log(FS_SSE.Theta_SSE(1)),assumed_dispersion);
plot(x,yDS1_SSE,'LineWidth',2,'DisplayName',"Superficial(SSE)",'Color',color(1,:),'LineStyle',':',"Marker",'+');
hold on
yDS2_SSE = cdf('Normal',log(x),log(FS_SSE.Theta_SSE(2)),assumed_dispersion);
plot(x,yDS2_SSE,'LineWidth',2,'DisplayName',"Compromised(SSE)",'Color',color(2,:),'LineStyle',':',"Marker",'+');
hold on
yDS3_SSE = cdf('Normal',log(x),log(FS_SSE.Theta_SSE(3)),assumed_dispersion);
plot(x,yDS3_SSE,'LineWidth',2,'DisplayName',"Critical(SSE)",'Color',color(3,:),'LineStyle',':',"Marker",'+');
hold on
%PB
yDS1_PB = cdf('Normal',log(x),log(FS_PB.Theta_PB(1)),assumed_dispersion);
plot(x,yDS1_PB,'LineWidth',2,'DisplayName',"Superficial(PB)",'Color',color(1,:),'LineStyle','-.',"Marker",'o');
hold on
yDS2_PB = cdf('Normal',log(x),log(FS_PB.Theta_PB(2)),assumed_dispersion);
plot(x,yDS2_PB,'LineWidth',2,'DisplayName',"Compromised(PB)",'Color',color(2,:),'LineStyle','-.',"Marker",'o');
hold on
yDS3_PB = cdf('Normal',log(x),log(FS_PB.Theta_PB(3)),assumed_dispersion);
plot(x,yDS3_PB,'LineWidth',2,'DisplayName',"Critical(PB)",'Color',color(3,:),'LineStyle','-.',"Marker",'o');
hold on
title(title_plot)
ax=gca;
ax.FontSize=18;
xlabel(x_axis_name)
ylabel("Probability of exceedence");
hold on
legend('Location',"southeast")
legend show
ax.XTick=xmin:0.5:xmax;
x0=10;
y0=30;
wdt=1000;
hgt=600;
grid on
set(gcf,'position',[x0,y0,wdt,hgt]);
saveas(gca,[pwd '/Fragility Analysis Result Figures/Output Folder/ALL_sys_beta_0.4.jpg']);
end