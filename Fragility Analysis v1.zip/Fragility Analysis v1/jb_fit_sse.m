function [parameters,sse,m, y, Normalitytest,p_val] = jb_fit_sse(Max_EDP_damage,IM, num_gms, num_collapse,dist_type,num_parameters,std_constrain,xmin,xmax)
% Date 09/17/2024
% Initial code by Jack Baker, 1/25/2017 for lognormal CDF only. 
% Further Developed and revised by Jitendra Bhatta to:
% 1. incorporate other CDFs.

% Modified by Jack Baker, 1/25/2017, to update citation information
%
% This function fits a lognormal CDF to observed probability of collapse 
% data by minimizing the sum of squared errors between the observed and
% predicted fractions of collapse. This approach is investigated in
% equation 12 of the following paper.
%
% Baker, J. W. (2015). �Efficient analytical fragility function fitting 
% using dynamic structural analysis.� Earthquake Spectra, 31(1), 579-599.
%
%
% INPUTS:
% IM            1xn           IM levels of interest
% num_gms       1x1 or 1xn    number of ground motions used at each IM level
% num_collapse 	1xn           number of collapses observed at each IM level
% 
% OUTPUTS:
% theta         1x1           median of fragility function
% beta          1x1           lognormal standard deviation of fragility function

% Further modified by Jitendra Bhatta 09/17/2024
% Jitendra Bhatta
% Postdoctoral Scholar, Department of Civil & 
% Systems Engineering, Johns Hopkins University, Baltimore, Maryland, US 
% and Guest researcher at National Institute of Science and Technology (NIST), 
% Gaithersburg, Maryland, US, ORCID number: 0000-0002-7188-8292
% Current email: jitendra.bhatta@canterbury.ac.nz



% reshape vectors into colum vectors
IM = IM(:);
num_gms = num_gms(:);
num_collapse = num_collapse(:);
if ~isequal(size(num_gms), size(num_collapse)) % if num_gms is scalar
    num_gms = num_gms * ones(size(num_collapse)); % build a vector of appropriate size
end

% Initial guess for the fragility function parameters theta and beta. 
% These initial choices should not need revision in most cases, but they 
% could be altered if needed.
%% Initial guess for the fragility function parameters theta and beta
% ** Use method of moments **
if dist_type=='LogNormal'
    x0 = [mean(log(Max_EDP_damage)) std(log(Max_EDP_damage))];
    LB=[-Inf 0.2];
    UB=[Inf 0.6];
elseif dist_type=='Normal'
     x0 = [mean(Max_EDP_damage) std(Max_EDP_damage)];
     LB=[0 0.2];
     UB=[Inf 0.6];
elseif dist_type=='Uniform' || dist_type=='Loguniform'
    x0=[min(Max_EDP_damage) max(Max_EDP_damage)];
else
    x0 = 0.5*ones(1,num_parameters);
end
%% Run optimization
options = optimset('MaxFunEvals',1000, 'GradObj', 'off'); %maximum 1000 iterations, gradient of the function not provided
if dist_type == 'Normal' || dist_type== 'LogNormal'
    if std_constrain==1
        [x,minval] = fminsearchbnd(@ssefit, x0,LB,UB, options, num_gms, num_collapse, IM,dist_type,std_constrain) ;
    else
       [x,minval] = fminsearch(@ssefit, x0, options, num_gms, num_collapse, IM,dist_type,std_constrain) ;
    end
else
        [x,minval] = fminsearch(@ssefit, x0, options, num_gms, num_collapse, IM,dist_type,std_constrain) ;
end

%Rsq=-minval;
sse=minval;
parameters=zeros(1,4);
for i = 1: length(x)
    parameters(i)=x(i);
end
parameters(parameters==0)=NaN;
if std_constrain==1
    if dist_type=="LogNormal"||dist_type=="Normal"
        %if parameters(2)==0
        %    ini_beta=0.0000000001;
        %else
            ini_beta=parameters(2);
        %end
        %ini_theta=parameters(1);
        parameters(2)=correct_beta(ini_beta);
        %ra=sum(IM.*num_gms)/length(num_gms);
        %parameters(1)=ra*(ra./ini_theta)^(parameters(2)/ini_beta);
    end
end

m=linspace(xmin,xmax);

if dist_type=="exp" 
         y =  1- exp(-x(1)*m.^x(2)); % predicted probabilities
    else 
    if numel(x)==1
        y =  cdf(dist_type,m,x(1)); % predicted probabilities
    elseif numel(x)==2
        y =  cdf(dist_type,m,x(1),x(2)); % predicted probabilities
    elseif numel(x)==3
        y =  cdf(dist_type,m,x(1),x(2),x(3)); % predicted probabilities
    elseif numel(x)==4
        y =  cdf(dist_type,m,x(1),x(2),x(3),x(4)); % predicted probabilities
    end
end
     Normalitytest="NA";
     p_val=NaN;


%% objective function to be optimized
function [sse] = ssefit(params, num_gms, num_collapse, IM,dist_type,std_constrain)

if numel(params(exp(params)<0))>0
    sse = 1e10;
elseif dist_type=='Uniform' && params(1)>=params(2)
    sse = 1e10;
elseif dist_type=='Loguniform' && params(1)>=params(2)
    sse = 1e10;
else
    if dist_type=="exp" 
            p =  1- exp(-params(1)*IM.^params(2)); % predicted probabilities
    else
            if numel(params)==1
                p =  cdf(dist_type,IM,params(1)); % predicted probabilities
            elseif numel(params)==2
                p =  cdf(dist_type,IM,params(1),params(2)); % predicted probabilities
            elseif numel(params)==3
                p =  cdf(dist_type,IM,params(1),params(2),params(3)); % predicted probabilities
            elseif numel(params)==4
                p =  cdf(dist_type,IM,params(1),params(2),params(3),params(4)); % predicted probabilities
            end
     end

    sse = sum( (p - num_collapse./num_gms).^2); % sum of squared errors between estimated and observed probabilities
    
    SStot = sum((num_collapse./num_gms-mean(num_collapse./num_gms)).^2);                    % Total Sum-Of-Squares

    Rsq = -(1-sse/SStot);   
end