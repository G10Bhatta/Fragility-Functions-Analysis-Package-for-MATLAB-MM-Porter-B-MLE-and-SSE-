function [parameters,LL, aic_val,m, y,Normalitytest,p_val] = jb_fit_mle(Max_EDP_damage,IM, num_gms, num_collapse,dist_type,num_parameters,std_constrain,xmin,xmax)
%The parameters of the CDF functions are estimated using 
% Maximum Likelihood Estimation (MLE) method (Cremen and Baker, 2019; Rota et al., 
% 2008; Shinozuka et al., 2000).
%
% INPUTS
% 1. IM        intensity measured
% 2. num_gms       number of tests/ground motions at each intensity measure
% 3. num_collapse 	number of collapses observed at each intensity measure
% 4. Other inputs for this function are provided in the
% Main_fragility_analysis_file.m file.

% OUTPUT:
% parameters estimation,LogLik and AIC. Normalitytest,p_val are calculated
% in the file calling this functions therefore are NaN here. 
% It plots the CDF functions.
%-------------------------------------------------------------------------
% Date 09/17/2024
% Initial code by Jack Baker, 1/25/2017 for lognormal CDF only. 
% Further Developed and revised by Jitendra Bhatta to:
% 1. incorporate other % CDFs.
% 2. Option is available to correct the median based on new disperson, if required.
% Jitendra Bhatta
% Postdoctoral Scholar, Department of Civil & 
% Systems Engineering, Johns Hopkins University, Baltimore, Maryland, US 
% and Guest researcher at National Institute of Science and Technology (NIST), 
% Gaithersburg, Maryland, US, ORCID number: 0000-0002-7188-8292
% Current email: jitendra.bhatta@canterbury.ac.nz
%-------------------------------------------------------------------------


%% Initial guess for the fragility function parameters theta and beta
% ** Use method of moments **
if dist_type=='LogNormal'
    x0 = [mean(log(Max_EDP_damage)) std(log(Max_EDP_damage))];
    LB=[-Inf 0.2];                   % lower bound values for median and beta
    UB=[Inf 0.6];                   % upper bound values for median and beta
elseif dist_type=='Normal'
     x0 = [mean(Max_EDP_damage) std(Max_EDP_damage)];
     LB=[0 0.2];
     UB=[Inf 0.6];
elseif dist_type=='Uniform' || dist_type=='Loguniform'
    x0=[min(Max_EDP_damage) max(Max_EDP_damage)];
else
    x0 = 0.5*ones(1,num_parameters);
end


%% Run optimization
options = optimset('MaxFunEvals',1000, 'GradObj', 'off'); %maximum 1000 iterations, gradient of the function not provided
if dist_type == 'Normal' || dist_type== 'LogNormal'
    if std_constrain==1
        [x,minval] = fminsearchbnd(@mlefit_exp, x0,LB,UB, options, num_gms, num_collapse, IM,dist_type,std_constrain) ;
    else
       [x,minval] = fminsearch(@mlefit_exp, x0, options, num_gms, num_collapse, IM,dist_type,std_constrain) ;
    end
else
        [x,minval] = fminsearch(@mlefit_exp, x0, options, num_gms, num_collapse, IM,dist_type,std_constrain) ;
end

parameters=zeros(1,4);
for i = 1: length(x)
    parameters(i)=x(i);
end
parameters(parameters==0)=NaN;
LL=-minval;
aic_val=2*length(x0)- 2*LL;
m=linspace(xmin,xmax);

if dist_type=="exp" 
         y =  1- exp(-x(1)*m.^x(2)); % predicted probabilities
    else 
    if numel(x)==1
        y =  cdf(dist_type,m,x(1)); % predicted probabilities
    elseif numel(x)==2
        y =  cdf(dist_type,m,x(1),x(2)); % predicted probabilities
    elseif numel(x)==3
        y =  cdf(dist_type,m,x(1),x(2),x(3)); % predicted probabilities
    elseif numel(x)==4
        y =  cdf(dist_type,m,x(1),x(2),x(3),x(4)); % predicted probabilities
    end
end
     Normalitytest="NA";
     p_val=NaN;

%% Objective function to be optimized
function [loglik] = mlefit_exp(params, num_gms, num_collapse, IM,dist_type,std_constrain)

if numel(params(exp(params)<0))>0
    loglik = 1e10;
elseif dist_type=='Uniform' && params(1)>=params(2)
    loglik = 1e10;
elseif dist_type=='Loguniform' && params(1)>=params(2)
    loglik = 1e10;
else 
    if dist_type=="exp" 
        p =  1- exp(-params(1)*IM.^params(2)); % predicted probabilities
    % estimated probabilities of collapse, given the current fragility function
    % parameter estimates
    else
    if numel(params)==1
        p =  cdf(dist_type,IM,params(1)); % predicted probabilities
    elseif numel(params)==2
        p =  cdf(dist_type,IM,params(1),params(2)); % predicted probabilities
    elseif numel(params)==3
        p =  cdf(dist_type,IM,params(1),params(2),params(3)); % predicted probabilities
    elseif numel(params)==4
        p =  cdf(dist_type,IM,params(1),params(2),params(3),params(4)); % predicted probabilities
    end
    end

    % likelihood of observing num_collapse(i) collapses, given num_gms
    % observations, using the current fragility function parameter estimates
    likelihood = binopdf(num_collapse', num_gms', p'); %
    
    % ** Cannot have zero likelihood value, so replace every zero likelihood 
    % value with the smallest positive normalized fixed-point value **
    likelihood(likelihood == 0) = realmin;
    
    % sum negative log likelihood (we take the negative value because we want
    % the maximum log likelihood, and the function is searching for a minimum)
    loglik = -sum(log(likelihood));
end