function [R]=fittoecdfmle(Max_EDP_damage,data, num_gms1,num_collapse1,only_normal, std_constrain,x_axis_name,xmin,xmax,plot_title,DS_title, color, num_bestfits,uniQ,pierce)

%{
if uniQ==1
    [data,indx]=unique(data)
    num_gms1=num_gms1(indx)
    num_collapse1=num_collapse1(indx)
end

if pierce==1
try
[outlierIdx,inlierIdx,outlierObs] = peirces(data);
IM=data(inlierIdx);

catch
IM=data;
end
num_gms=num_gms1(inlierIdx);
num_collapse=num_collapse1(inlierIdx);
else
    IM=data;
    num_gms=num_gms1;
    num_collapse=num_collapse1;
end
%}
IM=data;
num_gms=num_gms1;
num_collapse=num_collapse1;
fraction=num_collapse./num_gms;

if only_normal==0
dist_type=["Beta", "Binomial", "BirnbaumSaunders", "Burr", "chi2","Exponential", "Extreme Value",...
    "F","Gamma","Generalized Extreme Value", "Generalized Pareto", "Geometric", "Half Normal", "Hypergeometric",...
    "InverseGaussian", "Logistic", "LogLogistic", "LogNormal", "Loguniform", "Pearson", "Nakagami", "Negative Binomial",...
    "Noncentral F", "Noncentral t", "Noncentral Chi-square", "Normal", "Poisson", "Rayleigh", "Rician", "Stable", "T",...
    "tLocationScale", "Uniform", "Discrete Uniform", "Weibull", "exp"];
num_parameters=[2 2 2 3 1 1 2 2 2 3 3 1 2 3 2 2 2 2 2 4 2 2 3 2 2 2 1 1 2 4 1 3 2 1 2 2];
elseif only_normal==1 
dist_type=["LogNormal"];
num_parameters=[2];
end

parameters=zeros(1,4);
for i = 1: length(dist_type)
    [parameters(i,:), LL(i), aic(i),m, y(i,:),Normalitytest(i),p_val(i)] = jb_fit_mle(Max_EDP_damage,IM, num_gms,num_collapse,dist_type(i),num_parameters(i),std_constrain,xmin,xmax);
end

[B, I]=sort(aic);
Name=dist_type(I)';
LogLik=LL(I)';
AIC=aic(I)';
y_sort=y(I,:);
ks_test=Normalitytest(I)';
parameters_sort=parameters(I,:);
p_value=p_val(I)';
R=table(Name,parameters_sort,LogLik,AIC,ks_test,p_value);


if only_normal==0
    for i = 1: num_bestfits
         plot(m,y_sort(i,:),'DisplayName',Name(i),'LineWidth',2);
    end
else
    plot(m,y_sort,'DisplayName',DS_title,'Color',color,'LineWidth',2);
end
hold on
scatter(IM, fraction,"filled",'DisplayName',append("M/N ",DS_title),'MarkerFaceColor',color, 'MarkerEdgeColor',color);

%title(plot_title);
xlabel(x_axis_name);
ylabel("Probability of exceedence")
grid on
ax=gca;
ax.FontSize=18;
legend show
legend ('Location','southeast')
ylim([0 1]);
ax.XTick=xmin:0.5:xmax;
x0=10;
y0=30;
wdt=900;
hgt=500;
set(gcf,'position',[x0,y0,wdt,hgt]);







