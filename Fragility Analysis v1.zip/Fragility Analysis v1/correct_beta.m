function [cor_beta]=correct_beta(beta)

% making beta = 0.6 when beta goes above 0.6 (Jitendra)
if beta>0.6 
    cor_beta=0.6;
elseif beta<=0.2 && beta>0
    cor_beta =0.2;
elseif beta<=0
    cor_beta=0.6;
else
    cor_beta=beta;
end
%}