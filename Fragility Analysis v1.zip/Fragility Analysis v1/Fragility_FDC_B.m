function [Median_demand,Total_dispersion,normaltest_log,IM, num_gms, num_collapse ]=Fragility_FDC_B(Max_EDP1,fi1,std_constrain,option, xmin, xmax, plot_title, x_axis_name, DS_title,color)

% In this method, the data are divided into bins depending upon the intensity measures 
% such that each bin contains approximately the same number of specimens. 
% For each bin, the collapse fraction (i.e. number of failed specimens/ total number of specimens) 
% and average intensity measures are calculated. 
% A linear equation y=mx+c  is fitted to the inverse standard normal distribution 
% of the fractions vs. the natural logarithm of the average intensity measures plot. 
% Then, the median and random dispersion parameters of the lognormal CDF are estimated 
% Refer to (Porter, K. et al., 2006; Porter, Keith et al., 2007) for detailed description of this method. 
% (Porter, K. et al., 2006) recommends using SSE method approach over PB to fit binary failure data 
% i.e. collapse fractions include 0 and 1 and SSE is found to avoid errors that may arise with 
% bin-average intensity measures. 

% Steps include:
%   1. Sorting the intensity measures in ascedning order.
%   2. Creating a number of bins such that each bin has approcimately equal number of specimens
%   3. Obtaining average intensity measures for each bin 
%   4. Fitting a linear equation y=mx+c  to the inverse standard normal distribution 
%       of the fractions vs. the natural logarithm of the average intensity
%       measures plot. I have provided three options if the proposed
%       equation by Porter Method B doesn't work (i.e. option 1) 
% NOTE:
%    There are three options:
%   Option 1:
%       The prescribed formula to obtain norm inverse of collapse fraction by porter is :
%               yj=norminv((mj+1)./(Mj+1))
%       It doesn't give values for norminv(0) and norminv(1). Hence, non-convergent. 
%   Option 2:
%       The collapse fractions are calculated as below, where, approximate collapse 
%       fractions are usef for fractions equal to 0 and 1.
        %{
            fr=mj./Mj;                              
            fr(N)=mj(N)./Nj;
            fr(fr==1)=0.999;               %Approximation to 1
            fr(fr==0)=0.001;               %Approximation to 0
            yj=norminv(fr);
            %}
%Option 3: involves fitting linear curve to mj./Mj vs. average demand in
%real space. Therefore, doesn't have issue of binary data. 

%   5. Calculating the median and random dispersion
%   6. Plots the CDF function and empirical CDF (ECDF)
%   7. Conducts Lilliefors Goodness of fit testing (Lilliefors 1967; Annex H FEMA P-58
%       2012) for the average demands. 
%   8. the median can be updated if dispersion is constrained to a value or
%       if uncertainty dispersion is introduced by running sections of the code
%       below where indicated 
%-------------------------------------------------------------------------
% Date 09/17/2024
% Developed by Jitendra Bhatta. Postdoctoral Scholar, Department of Civil & 
% Systems Engineering, Johns Hopkins University, Baltimore, Maryland, US 
% and Guest researcher at National Institute of Science and Technology (NIST), 
% Gaithersburg, Maryland, US, ORCID number: 0000-0002-7188-8292
% email: jbh103@uclive.ac.nz
%-------------------------------------------------------------------------

Max_EDP=Max_EDP1;
fi=fi1;
[Max_EDP_sort, a_order]=sort(Max_EDP);
new_fi=fi(a_order);
M=length(Max_EDP);                                  % Number of specimens   
N=floor(sqrt(M));                                   % Number of bins
Mj=floor(M/N);                                     % Number of specimens in each bins
Nj=M-Mj*(N-1);

count=1;
for i = 1 : N
    demand=0;
    fi_sum=0;
    if i <N
        for j = 1: Mj
            demand= demand+Max_EDP_sort(count);
            fi_sum=fi_sum+new_fi(count);
            count=count+1;
        end
        Average_demand(i)=demand/Mj;
        mj(i)=fi_sum;
        num_gms(i)=Mj;
    elseif i==N
         for j = 1: Nj
            demand= demand+Max_EDP_sort(count);
            fi_sum=fi_sum+new_fi(count);
            count=count+1;
        end
        Average_demand(i)=demand/Nj;
        mj(i)=fi_sum;
        num_gms(i)=Nj;
    end
end
xj=log(Average_demand);
xj=log(Average_demand);

if option==1
% Option 1: Use this if using formula by Porter in norminverse vs. log space 
% provided method by Porter (2007)
yj=norminv((mj+1)./(Mj+1));
yj(N)=norminv((mj(N)+1)./(Nj+1));
p = polyfit(xj,yj,1);    % in norminverse vs. log space
Random_dispersion=1/p(1);
Median_demand=exp(-p(2)*Random_dispersion);
%{
if std_constrain==1
    Random_dispersion=correct_beta(1/p(1));
    % this code corrects the median, if required. 
    %ra=sum(Average_demand)./length(Average_demand);
    %Median_demand=ra*(ra./exp(-p(2)*Random_dispersion))^(correct_beta(1/p(1))/(1/p(1)));
end
%}
Total_dispersion=Random_dispersion;

elseif option ==2
%Option 2 below to solve issue of non-convergence for yj=0
%and yj=1 (binary data)
%approximating collapse fractions close to 0 and 1.

fr=mj./Mj;                              
fr(N)=mj(N)./Nj;
fr(fr==1)=0.999;               %Approximation to 1
fr(fr==0)=0.001;               %Approximation to 0
yj=norminv(fr);
p = polyfit(xj,yj,1);    % in norminverse vs. log space
Random_dispersion=1/p(1);
Median_demand=exp(-p(2)*Random_dispersion);
%{
if std_constrain==1
    Random_dispersion=correct_beta(1/p(1));
    % this code corrects the median, if required. 
    %ra=sum(Average_demand)./length(Average_demand);
    %Median_demand=ra*(ra./exp(-p(2)*Random_dispersion))^(correct_beta(1/p(1))/(1/p(1)));
end
%}
Total_dispersion=Random_dispersion;
else 

%option 3 to solve issue of non-convergence for yj=0
%and yj=1 (binary data) in real space (collapse fractions vs. average demand)
p=polyfit(Average_demand,mj./Mj, 1);              
Random_dispersion=1/p(1);
%Covariance = cov(Average_demand,mj./Mj);    
%Random_dispersion=Covariance(1,1)/Covariance(1,2)
Median_demand=(0.5-p(2))*Random_dispersion;
%{
if std_constrain==1
    Random_dispersion=correct_beta(1/p(1));
    % this code corrects the median, if required. 
    %ra=sum(Average_demand)./length(Average_demand);
    %Median_demand=ra*(ra./(0.5-p(2))*Random_dispersion)^(correct_beta(1/p(1))/(1/p(1)));
end
%}
Total_dispersion=Random_dispersion;
end

% FEMA P-58 recommendation, if required, otherwise only give random
% dispersion

%{   
Uncertanity_dispersion=0.25;
Total_dispersion=sqrt(Uncertanity_dispersion^2+Random_dispersion^2);

if std_constrain==1
    % this code corrects the median, if required. 
    %ra=sum(Average_demand)./length(Average_demand);
    %Median_demand=ra*(ra./Mean_logvals)^(-correct_beta(Total_dispersion)/Total_dispersion);
    Total_dispersion=correct_beta(Total_dispersion);
end
%}    

IM=Average_demand;
num_collapse=mj;
num_gms=num_gms;

% Plotting Fragility curve
x=linspace(xmin,xmax);
yA = cdf('Normal',log(x),log(Median_demand),Total_dispersion);
plot(x,yA,'LineWidth',2,'DisplayName',DS_title,'Color',color);
hold on
scatter(IM,num_collapse./num_gms,'filled','Displayname',append("M/N ",DS_title),'MarkerFaceColor',color,'MarkerEdgeColor',color)
yA_DS = cdf('Normal',log(Max_EDP_sort),log(Median_demand),Total_dispersion);

%title(plot_title);
ax=gca;
ax.FontSize=18;
xlabel(x_axis_name)
ylabel("Probability of exceedence");
hold on
legend show
legend('Location','southeast')
ylim([0 1]);
grid on
ax.XTick=xmin:0.5:xmax;
x0=10;
y0=30;
wdt=900;
hgt=500;
set(gcf,'position',[x0,y0,wdt,hgt]);

% Lilliefors Goodness of fit testing (Lilliefors 1967) Annex H FEMA P-58
% (2012)
try
h_log = lillietest(IM);
if h_log==0
    normaltest_log="Normal";
elseif  h_log==1
    normaltest_log="Not normal";
end
catch
    normaltest_log="Not enough data";
end

