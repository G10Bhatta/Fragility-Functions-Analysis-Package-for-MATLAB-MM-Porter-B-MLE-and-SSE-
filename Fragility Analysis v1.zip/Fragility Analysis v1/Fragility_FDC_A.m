function [Median_demand,Total_dispersion,normaltest_log, R]=Fragility_FDC_A(DS_intensity,std_constrain,xmin, xmax, plot_title, x_axis_name, DS_title,color)

% This gives the lognormal CDF parameters (median and dispersion) for given
% damage data using the Method-of-Moments (MM) or Method A in Porter(2007).
% Steps include:
%   1. Runs pierces criteria to eliminate outliers.
%   2. Calculates the median and random dispersion. 
%   3. Plots the CDF function and empirical CDF (ECDF)
%   4. Conducts Lilliefors Goodness of fit testing (Lilliefors 1967; Annex H FEMA P-58
%       2012)
%   5. It can conduct normality checks other than Lilliefors by running
%      R=normalitytest(DS_intensity_peirces) below.By default, it is an empty matrix, R=[]; 
%  6. the median can be updated if dispersion is constrained to a value or
%       if uncertainty dispersion is introduced by running sections of the code
%       below where indicated 
%-------------------------------------------------------------------------
% Date 09/17/2024
% Developed by Jitendra Bhatta. Previously. Postdoctoral Scholar, Department of Civil & 
% Systems Engineering, Johns Hopkins University, Baltimore, Maryland, US 
% and Guest researcher at National Institute of Science and Technology (NIST), 
% Gaithersburg, Maryland, US, ORCID number: 0000-0002-7188-8292
% Current email: jitendra.bhatta@canterbury.ac.nz
%-------------------------------------------------------------------------

try
[outlierIdx,inlierIdx,outlierObs] = peirces(DS_intensity)
DS_intensity_peirces=DS_intensity(inlierIdx)
catch
DS_intensity_peirces=DS_intensity;
end
% Median and dispersion calculation
M=length(DS_intensity_peirces);
Mean_logvals=exp(mean(log(DS_intensity_peirces)));
Median_demand=Mean_logvals;
standard_dev=std(log(DS_intensity_peirces));
Random_dispersion=standard_dev;
%{
if std_constrain==1
    Random_dispersion=correct_beta(standard_dev);  
    % this code corrects the median based on new disperson, if required. 
    %ra=sum(DS_intensity_peirces)./length(DS_intensity_peirces);
    %Median_demand=ra*(ra./Mean_logvals)^(-correct_beta(standard_dev)/standard_dev);
end
%}
Total_dispersion=Random_dispersion;

% FEMA P-58 recommendation, if required, otherwise only give random
% dispersion
%{   
    Uncertanity_dispersion=0.25;
    Total_dispersion=sqrt(Uncertanity_dispersion^2+Random_dispersion^2);
if std_constrain==1
    % this code corrects the median, if required. 
    %ra=sum(DS_intensity_peirces)./length(DS_intensity_peirces);
    %Median_demand=ra*(ra./Mean_logvals)^(-correct_beta(Total_dispersion)/Total_dispersion);
    Total_dispersion=correct_beta(Total_dispersion);
end

%}
% Plotting Fragility curve
x=linspace(xmin,xmax);
yA = cdf('Normal',log(x),log(Median_demand),Total_dispersion);
plot(x,yA,'LineWidth',2,'DisplayName',DS_title,'Color',color);
hold on
%ECDF
[fA,xA] = ecdf(DS_intensity_peirces);
hold on
scatter(xA,fA,"filled","DisplayName",append("ECDF ",DS_title),"MarkerFaceColor",color,"MarkerEdgeColor",color)
legend show
grid on
%title(plot_title);
ax=gca;
ax.FontSize=18;
xlabel(x_axis_name)
ylabel("Probability of exceedence");
hold on
legend('Location',"southeast")
legend show
ax.XTick=xmin:0.5:xmax;
x0=10;
y0=30;
wdt=900;
hgt=500;
set(gcf,'position',[x0,y0,wdt,hgt]);

% Lilliefors Goodness of fit testing (Lilliefors 1967) Annex H FEMA P-58
% (2012)
try
h_log = lillietest(DS_intensity_peirces);
if h_log==0
    normaltest_log="Normal";
elseif  h_log==1
    normaltest_log="Not Normal";
end
catch
    normaltest_log="Not enough data";
end

R=[];
% R=normalitytest(DS_intensity_peirces); Gives a matrix for other normality
%checks. By default, it is an empty matrix, R=[]; 



