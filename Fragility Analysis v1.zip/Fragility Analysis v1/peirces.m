function [outlierIndices,inlierIndices,outliers] = peirces(deltas,num_unknowns)
% Apply Peirce's criterion for outlier detection for arbitrary number of observations 3 or more. 
% Gould's implementation of Peirce's method is used.
%
% Usage: Input DELTAS is a vector of the observations (or fit errors)
% Optional second input NUM_UNKNOWS is the number of "unknown quantities".
% Default value is 1 which is generally the case as argued by the authors.
% The function returns linear indices of outliers (OUTLIERINDICES), linear indices of 
% observations which are found to be worthy of keeping (INLIERINDICES), and
% actual observations that are flagged as outliers.
% 
% References:
% B.A.Gould (1855), ON PEIRCE’S CRITERION FOR THE REJECTION OF DOUBTFUL OBSERVATIONS, WITH TABLES FOR FACILITATING ITS APPLICATION.
% The Astronomical Journal, No.83, Vol. IV.
%
% B.PEIRCE (1852), CRITERION FOR THE REJECTION OF DOUBTFUL OBSERVATIONS.
% The Astronomical Journal, No.45, Vol. II.
%
% S.M.ROSS, Peirce's criterion for the elimination of suspect experimental data
% Journal of Engineering Technology, Fall 2003. 
% 
%%%  
% Author: Chandrakanth R. Terupally
% E-mail: ck@plancktek.com
% Release: 1.0.1
% Release date: Nov 03, 2021

narginchk(1,2)
m = mean(deltas);
s = std(deltas);
N = length(deltas);
deltasCopy = deltas;
if nargin==1
    num_unknowns = 1;
end
assert(length(deltas)>2,'Minimum number of observations needed is 3.')
numOutliers = 1;
while numOutliers > 0
    devMax = s*Rratio(N,numOutliers,num_unknowns);
    deviants = abs(deltas-m)>=devMax;
    deltas(deviants) = NaN;
    numOutliers = sum(deviants);
    numOutliers = (numOutliers~=0)*(numOutliers+1);
end

nandata = isnan(deltas);
outliers = deltasCopy(nandata);
outlierIndices = find(nandata);
inlierIndices = find(~nandata);


function x = Rratio(N,n,m)
% Gould's method of Peirce's criterion

QN = (n^n)*((N-n)^(N-n))/N^N;
R = 1;
Rold = 0;
while abs(R-Rold) > N*eps
    lambda = (QN/R^n)^(1/(N-n));
    x = sqrt(1+ (N-m-n)*(1-lambda^2)/n);
    Rold = R;
    if ~isreal(x)
        x = NaN;
    else
        R = exp((x^2-1)/2) * erfc(x/sqrt(2));
    end
end

